from django.apps import AppConfig


class MedicalhubadminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'medicalhubadmin'
