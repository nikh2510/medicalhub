from django.shortcuts import render

# Create your views here.
	
def index(request):
    return render(request,"shopkeeper/home.html")

def home(request):
    return render(request,"shopkeeper/home.html")

def about(request):
    return render(request,"shopkeeper/about.html") 
def services(request):
    return render(request,"shopkeeper/services.html") 

def contact(request):
    return render(request,"shopkeeper/contact.html") 