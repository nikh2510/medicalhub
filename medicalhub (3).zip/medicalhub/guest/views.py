from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse


def index(request):
    return render(request,"guest/home.html")

def home(request):
    return render(request,"guest/home.html")

def about(request):
    return render(request,"guest/about.html") 
    
def services(request):
    return render(request,"guest/services.html") 

def contact(request):
    return render(request,"guest/contact.html") 